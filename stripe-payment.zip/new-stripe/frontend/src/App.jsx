import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ItemsList from "./components/ItemList";
import Success from "./components/Success";
import Cancel from "./components/Cancel";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<ItemsList />} />
        <Route path="/success" element={<Success />} />
        <Route path="/cancel" element={<Cancel />} />
      </Routes>
    </Router>
  );
}

export default App;
