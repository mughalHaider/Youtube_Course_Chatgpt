import React, { useState } from "react";
import { loadStripe } from "@stripe/stripe-js";

const stripePromise = loadStripe("pk_test_51QzmjiC07rJhxg5uwG22pEF3ONrnxdAssPG6jJ8tTCJ7aI4RSXPFcH1F3QL0aMIJrVDY4f5sXbCh4m1irO8lfYjB00MNDsZrHK");

const items = [
  { id: 1, name: "Item 1", price: 10 },
  { id: 2, name: "Item 2", price: 15 },
  { id: 3, name: "Item 3", price: 20 },
  { id: 4, name: "Item 4", price: 25 },
  { id: 5, name: "Item 5", price: 30 },
  { id: 6, name: "Item 6", price: 35 },
  { id: 7, name: "Item 7", price: 40 },
  { id: 8, name: "Item 8", price: 45 },
  { id: 9, name: "Item 9", price: 50 },
  { id: 10, name: "Item 10", price: 55 },
];

const ItemsList = () => {
  const [selectedItems, setSelectedItems] = useState([]);

  const addToList = (item) => {
    if (!selectedItems.find((selected) => selected.id === item.id)) {
      setSelectedItems([...selectedItems, item]);
    }
  };

  const totalPrice = selectedItems.reduce((total, item) => total + item.price, 0);

  const handleCheckout = async () => {
    if (selectedItems.length === 0) {
      alert("Please add items before checkout.");
      return;
    }

    const stripe = await stripePromise;
    const response = await fetch("http://localhost:5000/create-checkout-session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items: selectedItems }),
    });

    const session = await response.json();
    if (session.url) {
      window.location.href = session.url;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-6">
      <div className="max-w-3xl mx-auto bg-white shadow-lg rounded-lg p-6">
        <h1 className="text-3xl font-extrabold text-gray-800 text-center mb-6">🛍️ Available Items</h1>

        {/* Items Grid */}
        <div className="grid grid-cols-2 gap-6">
          {items.map((item) => (
            <div key={item.id} className="bg-gray-50 p-4 rounded-lg shadow-md transition-transform transform hover:scale-105">
              <h2 className="text-lg font-semibold text-gray-700">{item.name}</h2>
              <p className="text-gray-500">💰 Price: <span className="text-gray-800 font-bold">${item.price}</span></p>
              <button
                onClick={() => addToList(item)}
                className="mt-3 w-full bg-blue-500 text-white font-bold py-2 rounded-lg transition hover:bg-blue-600"
              >
                ➕ Add to List
              </button>
            </div>
          ))}
        </div>

        {/* Selected Items */}
        <div className="mt-8">
          <h2 className="text-2xl font-semibold text-gray-800">🛒 Selected Items</h2>
          {selectedItems.length === 0 ? (
            <p className="text-gray-500 mt-2">No items added yet.</p>
          ) : (
            <ul className="mt-4 space-y-3">
              {selectedItems.map((item) => (
                <li key={item.id} className="flex justify-between bg-gray-50 p-3 rounded-lg shadow">
                  <span className="font-medium text-gray-700">{item.name}</span>
                  <span className="font-semibold text-gray-800">${item.price}</span>
                </li>
              ))}
            </ul>
          )}

          {/* Total Price & Checkout Button */}
          {selectedItems.length > 0 && (
            <>
              <h3 className="text-xl font-semibold text-gray-800 mt-6">💵 Total: <span className="text-green-600">${totalPrice}</span></h3>
              <button
                onClick={handleCheckout}
                className="mt-4 w-full bg-green-500 text-white font-bold py-3 rounded-lg transition hover:bg-green-600"
              >
                ✅ Pay with Stripe
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ItemsList;
