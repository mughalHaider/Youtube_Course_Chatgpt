import { useSelector, useDispatch } from "react-redux";
import { removeFromCart } from "../counter/cartSlice";
import toast from "react-hot-toast";
import React from "react";

const Cart = () => {
  const cart = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  const handleRemoveFromCart = (id) => {
    dispatch(removeFromCart(id));
    toast.error("Item removed from cart!", {
      position: "top-center",
      duration: 2000,
    });
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Your Cart</h1>
      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {cart.map((item) => (
            <div key={item.id} className="border p-4 rounded flex justify-between items-center">
              <div>
                <h2 className="text-lg font-semibold">{item.title}</h2>
                <p>${item.price}</p>
              </div>
              <button
                onClick={() => handleRemoveFromCart(item.id)}
                className="bg-red-600 text-white p-2 rounded"
              >
                Remove from Cart
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Cart;
