import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchProducts } from "../counter/productsSlice";
import { addToCart } from "../counter/cartSlice";
import toast from "react-hot-toast";
import React from "react";

const Products = () => {
  const dispatch = useDispatch();
  const { items, status } = useSelector((state) => state.products);

  useEffect(() => {
    if (status === "idle") {
      dispatch(fetchProducts());
    }
  }, [status, dispatch]);

  const handleAddToCart = (product) => {
    dispatch(addToCart(product));
    toast.success("Item added to cart!", {
      position: "top-center",
      duration: 2000,
    });
  };

  return (
    <div className="p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {items.map((product) => (
        <div key={product.id} className="border p-4 rounded">
          <img src={product.image} alt={product.title} className="h-40 w-full object-cover" />
          <h2 className="text-lg font-semibold">{product.title}</h2>
          <p>${product.price}</p>
          <button
            onClick={() => handleAddToCart(product)}
            className="cursor-pointer mt-2 p-2 bg-blue-600 text-white rounded"
          >
            Add to Cart
          </button>
        </div>
      ))}
    </div>
  );
};

export default Products;
