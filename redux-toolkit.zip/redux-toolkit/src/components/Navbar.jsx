import { Link } from "react-router-dom";
import React from "react";

const Navbar = () => {
  return (
    <nav className="p-4 bg-blue-600 text-white flex justify-between">
      <h1 className="text-xl font-bold">Redux Cart</h1>
      <div className="space-x-4">
        <Link to="/">Products</Link>
        <Link to="/cart">Cart</Link>
      </div>
    </nav>
  );
};

export default Navbar;
